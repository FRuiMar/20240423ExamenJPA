package examen.entidades;

public abstract class Entidad {

	/**
	 * Default Constructor.
	 */
	public Entidad() {
		super();
	}
	
}
